#include <stdio.h>
#include <stdlib.h>

void printfivestars(void);
int i;

int main()
{
    printfivestars();
    return 0;
}

void printfivestars(void)
{
    for(i=0;i<5;i++){
        printf("*");
    }
}
