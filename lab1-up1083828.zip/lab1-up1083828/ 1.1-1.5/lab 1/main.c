/*lab1 1.1-1.5 up1083828-�������� �������������*/

#include <stdio.h>
#include <stdlib.h>

void printfivechars(void);
void printnchars(int n, char ch);
void squarefive(void);
void squaren(int n);

char c;
int i,j,a;


int main()
{
    /* 1.1 */
    printfivechars();
    printf("\n");

    /* 1.2 */
    printnchars(5,'@');
    printf("\n");
    printnchars(15,'+');
    printf("\n");

    /* 1.3 */
    printf("\nPosous xarakthres thes? ");
    scanf("%d",&a);
    printnchars(a,'+');
    printf("\n\n");

    /* 1.4 */
    squarefive();

    /* 1.5 */
    squaren(3);

    return 0;
}

void printfivechars(void)
{
    for(i=0;i<5;i++){
        printf("@");
    }
    return;
}

void printnchars(int n, char ch)
{
    printf("\n");
    for(i=0;i<n;i++){
        printf("%c",ch);
    }
    return;
}

void squarefive(void)
{
    for(j=0;j<5;j++){
        printfivechars();
        printf("\n");
    }
    return;
}

void squaren(int n)
{
    for(j=0;j<n;j++){
        printnchars(n,'+');
    }
    return;
}
