/*lab1 1.6 up1083828-�������� �������������*/

#include <stdio.h>

int foreachrow(int N);
int foreachcolumn(int N);
int i, j, N;

int main()
{
    printf("Poses grammes thes na exei to tetragono? ");
    scanf("%d", &N);
    printf("\n");
    foreachrow(N);

    return 0;
}

int foreachrow(int N)
{
    for(i=1; i<=N; i++)
    {
        foreachcolumn(N);
        printf("\n"); /*allazei grammh*/
    }
}

int foreachcolumn(int N)
{
    for(j=1; j<=N; j++)
    {
        if(i==1 || i==N)
        {
            printf("q");
        }
        else if(j==1 || j==N)
        {
            printf("a");
        }
        else
        {
            printf("-");
        }
    }
}
