#include <stdio.h>
#include <stdlib.h>

int c,s,p,e;
char x;
int getchoice(void);
void choose_shape(void);
int tetragono(int p,char x);
int orth_trigono(int p,char x);
int isosk_trigono(int p, char x);
int romvos(int p, char x);

int main()
{
    int choice = 0;
    for (; choice != -1 ; ){
        choice = getchoice();
        if (choice >-1 ){
            choose_shape();
        }
    }
    return 0;
}

int getchoice(void)
{
    printf("\n=> an thelete na termatisei to programma plhktrologhste -1,diaforetika enan akeraio >=0: ");
    scanf("%d",&e);
    return e;
}

void choose_shape(void)
{
    printf("poio sxhma epilegete?\n\n");
    printf("pathste:\n0 - gia tetragono\n1 - gia romvo\n2 - gia orthogonio trigono\n3 - gia isoskeles trigono\n");
    scanf("%d",&s);
    printf("ti megethos thelete? ");
    scanf("%d",&p);
    printf("ti xarakthra thelete? ");
    scanf(" %c",&x);/*The blank in the format string tells scanf to skip leading whitespace,
    and the first non-whitespace character will be read with the %c conversion specifier.*/
    if (s==0){
        c=tetragono(p,x);
    }
    else if(s==1){
        c=romvos(p,x);
    }
    else if(s==2){
        c=orth_trigono(p,x);
    }
    else if(s==3){
        c=isosk_trigono(p,x);
    }
    else{
        printf("\nden yparxei ayth h epilogh, xanadokimaste\n");
    }
}

int tetragono(int p, char x)
{
    printf("tetragono");
    return 0;
}

int orth_trigono(int p, char x)
{
    printf("orth_trigono");
    return 0;
}

int isosk_trigono(int p, char x)
{
    printf("isosk_trigono");
    return 0;
}

int romvos(int p, char x)
{
    printf("romvos");
    return 0;
}
