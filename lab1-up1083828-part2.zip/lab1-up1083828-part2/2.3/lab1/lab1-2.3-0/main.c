#include <stdio.h>
#include <stdlib.h>

int c,s,p,e;
int getchoice(void);
void choose_shape(void);
int tetragono(int p);
int orth_trigono(int p);
int isosk_trigono(int p);
int romvos(int p);

int main()
{
    int choice = 0;
    for (; choice != -1 ; ){
        choice = getchoice();
        if (choice >-1 ){
            choose_shape();
        }
    }
    return 0;
}

int getchoice(void)
{
    printf("\n=> an thelete na termatisei to programma plhktrologhste -1,diaforetika enan akeraio >=0: ");
    scanf("%d",&e);
    return e;
}

void choose_shape(void)
{
    printf("poio sxhma epilegete?\n\n");
    printf("pathste:\n0 - gia tetragono\n1 - gia romvo\n2 - gia orthogonio trigono\n3 - gia isoskeles trigono\n");
    scanf("%d",&s);
    printf("ti megethos thelete? ");
    scanf("%d",&p);
    if (s==0){
        c=tetragono(p);
    }
    else if(s==1){
        c=romvos(p);
    }
    else if(s==2){
        c=orth_trigono(p);
    }
    else if(s==3){
        c=isosk_trigono(p);
    }
    else{
        printf("\nden yparxei ayth h epilogh, xanadokimaste\n");
    }
}

int tetragono(int p)
{
    printf("tetragono");
    return 0;
}

int orth_trigono(int p)
{
    printf("orth_trigono");
    return 0;
}

int isosk_trigono(int p)
{
    printf("isosk_trigono");
    return 0;
}

int romvos(int p)
{
    printf("romvos");
    return 0;
}
